import django.core.cache
from django.http import Http404, HttpResponseRedirect
from django.shortcuts import render, redirect
from .models import Books
from django.urls import reverse
from .forms import SignUpForm, UserCreationForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User


def index(request):
    latest_books_list = Books.objects.order_by()
    return render(request, 'lib/info.html', {'latest_books_list': latest_books_list})

def detail(request, book_id):
    try:
        a = Books.objects.get(id = book_id)
    except:
        raise Http404("Not found!")

    latest_comments_list = a.comments_set.order_by()

    return render(request, 'lib/detail.html',  {'book': a, 'latest_comments_list': latest_comments_list})

def leave_comment(request, book_id):
    try:
        a = Books.objects.get(id = book_id)
    except:
        raise Http404("Not found!")

    a.comments_set.create(comment_name = request.POST['name'], comment_text = request.POST['text'])

    return HttpResponseRedirect(reverse('ulib:detail', args = (a.id, )))

def signup(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            username = form.cleaned_data.get('name')
            password1 = form.cleaned_data.get('password1')
            password2 = form.cleaned_data.get('password2')
            form.save()
            new_user = authenticate(username = username, email = email, password1 = password1, password2 = password2)
            if new_user is not None:
                login(request, new_user)
                return redirect('/')

    form = SignUpForm()

    context = {
        "form":form
    }
    return render(request, 'lib/signup.html', context)

def login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        new_user = authenticate(username = username, password = password)
        if new_user is not None:
            login(request, new_user)
            return redirect('/signup')

    context = {}
    return render(request, 'lib/login.html', context)
