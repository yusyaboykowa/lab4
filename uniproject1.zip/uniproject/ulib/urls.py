from django.urls import path, include
from . import views


app_name = 'ulib'
urlpatterns = [
    path('', views.index, name = 'index'),
    path('<int:book_id>/', views.detail, name = 'detail'),
    path('<int:book_id>/leave_comment/', views.leave_comment, name = 'leave_comment'),
    path('signup/', views.signup, name = 'signup'),
    path('login/', views.login, name = 'login'),

]