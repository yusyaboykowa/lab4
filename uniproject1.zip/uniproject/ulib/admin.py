from django.contrib import admin
from .models import Form, Regform, Books, Comments, User, Librarier


admin.site.register(Form)
admin.site.register(Regform)
admin.site.register(Books)
admin.site.register(Comments)
admin.site.register(User)
admin.site.register(Librarier)