import datetime
from django.db import models
from django.utils import timezone


class Form(models.Model):
    form_books = models.CharField('form', max_length = 100)
    pub_date = models.DateTimeField('date')

class Regform(models.Model):
    regform = models.CharField('registration of books', max_length = 100)
    regfrom = models.CharField('salary', max_length = 100)
    pub_date = models.DateTimeField('date')

class Books(models.Model):
    books_name = models.CharField('name', max_length = 100)
    books_author = models.CharField('author', max_length = 100)
    books_year = models.CharField('year', max_length=100)
    books_edition = models.CharField('edition', max_length = 100)
    books_exposition = models.TextField('exposition')

    def __str__(self):
        return self.books_name

    def was_published_recently(self):
        return self.pub_date >= (timezone.now() - datetime.timedelta(days = 7))

class Comments(models.Model):
    book_id = models.ForeignKey(Books, on_delete = models.CASCADE)
    comment_name = models.CharField('name', max_length = 100)
    comment_text = models.CharField('comment', max_length = 200)

    def __str__(self):
        return self.comment_name

class User(models.Model):
    user_login = models.CharField('login', max_length = 100)
    user_password = models.CharField('password', max_length = 100)

class Librarier(models.Model):
    library_name = models.CharField('name', max_length = 100)
    librarier_login = models.CharField('login', max_length = 100)
    librarier_password = models.CharField('password', max_length = 100)

